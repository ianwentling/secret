import java.util.ArrayList;
import java.util.Scanner;
//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.

// I got help from the tutor.
public class Vending_Machine  {
    private static CandyVendingMachine VendingMachine = new CandyVendingMachine();
    public static void main(String[] args) {
        //TIP Press <shortcut actionId="ShowIntentionActions"/> with your caret at the highlighted text
        // to see how IntelliJ IDEA suggests fixing it.


        // Create Scanner for User Input
        Scanner scanner = new Scanner(System.in);

        System.out.println("Hello and welcome to the Vending Machine!");



        // Vending Machine
//        CandyVendingMachine = new CandyVendingMachine(CandyVendingMachine.LetterButton.A);
       CandyVendingMachine VendingMachine = new CandyVendingMachine();

       System.out.println("Here are your options:");






        System.out.println("\nSelect a button: A,B,C");
        UserMenu();


//       String A  = scanner.nextLine();




        Candy Hershey = new Candy();
        Candy MnM = new Candy();
        Candy MilkyWay = new Candy();

//        //List of Candies
//        ArrayList<Candy> CandyList = new ArrayList();
//        CandyList.add(Hershey);
//        CandyList.add(MnM);
//        CandyList.add(MilkyWay);



    }
    public static void UserMenu () {
        // Display available options
        VendingMachine.DisplayContents();
    }
}