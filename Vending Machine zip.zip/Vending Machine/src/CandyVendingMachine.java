import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;

public class CandyVendingMachine implements ICandyVendingMachine {


    //Enum for Vending slots
//    public enum LetterButton {A, B, C}


    // Instance Variables
    // private LetterButton letterButton;


//    public LetterButton getLetterButton() {
//        return letterButton;
//    }
//    public void setLetterButton(LetterButton letterButton) {
//        this.letterButton = letterButton;
//    }

    //List of Candies

    private Queue<Candy> HersheyList = new LinkedList<Candy>();

   public Queue<Candy>GetHersheyList()
   {
     return HersheyList;
   }

   private Queue<Candy> MilkyWayList = new LinkedList<Candy>();
   public Queue<Candy>GetMilkyWayList()
   {
       return MilkyWayList;
   }

    private Queue<Candy> MnMList = new LinkedList<>();
   public Queue<Candy>GetMnMList()
   {
       return MnMList;
   }


    private void AddCandy() {
        HersheyList.add(new Candy("Hershey", 1.75));
        MilkyWayList.add(new Candy("MilkyWay", 1.25));
        MnMList.add(new Candy("MnM", 1.00));
    }

    // Constructor
    public CandyVendingMachine() {

        AddCandy();
    }


    @Override
    public void TakeMoney(double amount) {
//      double balance = 10.0;
//      String Letter;
//       switch(Letter)
//       {
//         case 1:
//             Letter = GetHersheyList().peek().getname();
//             break;
//
//
//       }


    }

    @Override
    public void ReturnMoney(double amount) {

    }

    @Override
    public Candy VendItem(String slotCode) {
        return VendItem(slotCode);
    }

    @Override
    public String GetMachineInfo() {
        return "Candy Vending Machine - Slots: A,B,C";
    }

    @Override
    public String DisplayContents() {
        StringBuilder dc = new StringBuilder();
        if (GetHersheyList().size() > 0) {
            dc.append("A: " + "Hershey " + HersheyList.size() + "--"  + 1.75 + "\n");

        }
        else
        {
            dc.append("Not Available");
        }
        if (GetMilkyWayList().size() > 0) {
            dc.append("B: " + "MilkyWay " + MilkyWayList.size()+ "--" + 1.25+ "\n");
        }
        else{
            dc.append("Not Available");
        }
        if (GetMnMList().size() > 0) {
            dc.append("C: " + "MnM " + MnMList.size() + "--" + 1.00 + "\n");
        }
        else
        {
            dc.append("Not Available");
        }
        System.out.println(dc.toString());
        return dc.toString();
    }

}
