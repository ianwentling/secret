public class Candy implements Cloneable{






// Default Constructor
public Candy() {}

// Constructor

 public Candy (String name , double price  ) {
    this.name = name;
    this.price = price;
 }

//Properties
private String name;
public String getname()
{
    return name;
}
public void setname(String name)
{
    this.name = name;
}

private double price;
public double getPrice()
{
    return price;
}
public void setprice()
    {
        this.price = price;
    }





}
