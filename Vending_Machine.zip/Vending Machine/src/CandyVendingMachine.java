import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class CandyVendingMachine implements ICandyVendingMachine {


    //Enum for Vending slots
  public static enum LetterButton {A, B, C}



    // Instance Variables
 private Queue<Candy> SelectedItem;
 double balance = 0.0;


 public Queue<Candy> getSelectedItem() {
     return SelectedItem;
 }
 public void setSelectedItem(Queue<Candy> selectedItem)
 {
     SelectedItem = selectedItem;
 }



    //List of Candies

    private Queue<Candy> HersheyList = new LinkedList<Candy>();

   public Queue<Candy>GetHersheyList()
   {
     return HersheyList;
   }

   private Queue<Candy> MilkyWayList = new LinkedList<Candy>();
   public Queue<Candy>GetMilkyWayList()
   {
       return MilkyWayList;
   }

    private Queue<Candy> MnMList = new LinkedList<Candy>();
   public Queue<Candy>GetMnMList()
   {
       return MnMList;
   }


    private void AddCandy() {
        HersheyList.add(new Candy("Hershey", 1.75));
        MilkyWayList.add(new Candy("MilkyWay", 1.25));
        MnMList.add(new Candy("MnM", 1.01));
    }

    // Constructor
    public CandyVendingMachine() {

        AddCandy();

    }


    @Override
    public void TakeMoney(double amount) {


        while (amount > balance) {
            System.out.println("\nPlease enter " + amount);
            Scanner sc = new Scanner(System.in);
            double UserInput = Double.parseDouble(sc.nextLine().trim());
            balance += UserInput;
            if (amount > balance) {
                System.out.println("\nYou don't have enough money!");

            }

        }
        System.out.println("You have entered enough money!");
        Candy returnedItem = (Candy)VendItem(SelectedItem);
        System.out.println("Here is your Candy: " + returnedItem.getname());
    }

    @Override
    public void ReturnMoney(double amount) {
      while (amount < balance) {
//          System.out.println("\nHere is your change!" + balance - amount);
      }

    }

    @Override
    public Object VendItem(Queue selectedItem) {
        return selectedItem.poll();
    }

//    @Override
//    public Candy VendItem(Queue<Candy> selectedItem) {
//        return selectedItem.poll();
//    }

    @Override
    public String GetMachineInfo() {
        return "Candy Vending Machine - Slots: A,B,C";
    }

    @Override
    public String DisplayContents() {
        StringBuilder dc = new StringBuilder();
        if (GetHersheyList().size() > 0) {
            dc.append("A: " + "Hershey " + HersheyList.size() + "--"  + 1.75 + "\n");

        }
        else
        {
            dc.append("Not Available");
        }
        if (GetMilkyWayList().size() > 0) {
            dc.append("B: " + "MilkyWay " + MilkyWayList.size()+ "--" + 1.25+ "\n");
        }
        else{
            dc.append("Not Available");
        }
        if (GetMnMList().size() > 0) {
            dc.append("C: " + "MnM " + MnMList.size() + "--" + 1.01 + "\n");
        }
        else
        {
            dc.append("Not Available");
        }
        System.out.println(dc.toString());
        return dc.toString();
    }

}
